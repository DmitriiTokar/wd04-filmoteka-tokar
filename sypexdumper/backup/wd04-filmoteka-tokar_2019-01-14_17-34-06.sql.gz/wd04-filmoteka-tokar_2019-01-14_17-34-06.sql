#SXD20|20011|50641|70210|2019.01.14 17:34:06|wd04-filmoteka-tokar|0|1|3|
#TA films`3`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(1,'Такси 5','комедия1',2044),
(12,'Такси','комедия',1998),
(13,'Такси 3','комедия',2002)	;
