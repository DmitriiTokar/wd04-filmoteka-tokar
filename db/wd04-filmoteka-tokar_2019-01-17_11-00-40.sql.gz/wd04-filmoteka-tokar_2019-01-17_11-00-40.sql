#SXD20|20011|50641|70210|2019.01.17 11:00:40|wd04-filmoteka-tokar|0|1|2|
#TA films`2`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  `description` text NOT NULL,
  `photo` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(1,'Мстители','фантастика',2012,'','')	;
