#SXD20|20011|50641|70210|2019.01.04 18:10:35|wd04-filmoteka-tokar|0|1|2|
#TA films`2`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(1,'Такси 2','комедия',2000),
(2,'Облачный атлас','драма',2012)	;
